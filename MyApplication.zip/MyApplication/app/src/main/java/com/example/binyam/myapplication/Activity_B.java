package com.example.binyam.myapplication;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Activity_B extends Activity {
    WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        webview = (WebView) findViewById(R.id.webVandela);

        ActionBar actionBar=getActionBar();    // for displying back button
        actionBar.setDisplayHomeAsUpEnabled(true);

        webview.getSettings().setJavaScriptEnabled(true); // for enabling javascript
        webview.setWebViewClient(new MyWebViewClient()); // it loading the website in our webview
        webview.setWebViewClient(new WebViewClient(){ // for handling SSL
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error){
                handler.proceed();
            }
        });
        webview.loadUrl("https://andela.com/alc");
    }

    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
        startActivityForResult(intent,0);
        return true;
    }





}